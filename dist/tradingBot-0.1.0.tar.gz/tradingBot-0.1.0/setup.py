# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['tradingbot', 'tradingbot.clients']

package_data = \
{'': ['*']}

install_requires = \
['Pillow>=9.1.1,<10.0.0',
 'PyYAML>=6.0,<7.0',
 'colorama>=0.4.4,<0.5.0',
 'hydra-core>=1.2.0,<2.0.0',
 'kaleido==0.2.1',
 'pandas>=1.4.2,<2.0.0',
 'pathlib>=1.0.1,<2.0.0',
 'plotly>=5.8.0,<6.0.0',
 'pytest>=5.2,<6.0',
 'requests>=2.27.1,<3.0.0',
 'telegram-send>=0.34,<0.35']

setup_kwargs = {
    'name': 'tradingbot',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'drlux',
    'author_email': 'sorrentino.luca@outlook.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
